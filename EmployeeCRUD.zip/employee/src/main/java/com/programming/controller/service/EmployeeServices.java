package com.programming.controller.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.programming.controller.model.Employee;

@Component
public class EmployeeServices {

	private List<Employee> employeeDetails = new ArrayList<>();

	public List<Employee> getAllEmployee() {

		return employeeDetails;
	}

	public Employee getEmployee(int id) {

		return employeeDetails.stream().filter(emp -> emp.getId() == id).findFirst().get();

	}

	public String saveEmployee(Employee employee) {
		return employeeDetails.add(employee) ? "Record Successfully Saved " : "Some Problem Occured ";

	}

	public String updateEmployee(int id, Employee employee) {

		if (isValidEmployee(id)) {

			employeeDetails.stream().filter(emp -> emp.getId() == id).findFirst().ifPresent(emp -> {
				emp.setName(employee.getName());
				emp.setAccount(employee.getAccount());
				emp.setMailId(employee.getMailId());
			});

			return "Record Successfully Updated";
		}

		return "Invalid Employee ID ";

	}

	public String deleteEmployee(int id) {

		Employee employee = employeeDetails.stream().filter(emp -> emp.getId() == id).findFirst().get();

		return employeeDetails.remove(employee) ? "Record Successfully Deleted" : "Invalid Employee ID ";

	}

	public boolean isValidEmployee(int id) {
		return employeeDetails.stream().anyMatch(emp -> emp.getId() == id);
	}
}
