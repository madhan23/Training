package com.programming.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.programming.controller.model.Employee;
import com.programming.controller.service.EmployeeServices;

@RestController
@RequestMapping("api/v1")
public class EmployeeController {

	
	private int empid=1360;
	@Autowired
	private EmployeeServices employeeServices;

	@GetMapping("/employee")

	public List<Employee> getAllEmployee() {
		return employeeServices.getAllEmployee();

	}

	@GetMapping("/employee/{id}")
	public Employee getEmployee(@PathVariable("id") final int id) {
		return employeeServices.getEmployee(id);

	}

	@PostMapping("/employee")
	@ResponseStatus(HttpStatus.CREATED)
	public String saveEmployee(@RequestBody Employee employee) {
		employee.setId(++empid);
		return employeeServices.saveEmployee(employee);

	}

	@PutMapping("/employee/{id}")
	public String updateEmployee(@PathVariable("id") final int id, @RequestBody Employee employee) {
		return employeeServices.updateEmployee(id,employee);

	}

	@DeleteMapping("/employee/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public String deleteEmployee(@PathVariable("id") final int id) {
		return employeeServices.deleteEmployee(id);

	}

}
